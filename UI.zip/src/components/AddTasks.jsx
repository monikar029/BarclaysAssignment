import React, { useState } from 'react';

function AddTasks(props) {
    const [taskName, setTaskName] = useState('');
    const [priority, setPriority] = useState(0);
    const [status, setStatus] = useState('0');
    const [taskObj, setTaskObj] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault(); // Prevent default behaviour

        if (taskName === "") {
            alert("Task name is required");
            return;
        }

        const response = fetch(
            `http://localhost:5030/Tasks?taskName=${taskName}&priority=${priority}&status=${status}`,
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json", 
                },
            }
        ).then((response) => {
            console.log(response.status);
            if(response.status == 400){
                alert("Enter unique task name");
            }
            response.json()
                .then((response) => {
                    setTaskObj(response);
                    props.getAllData();
                })
        }).catch((error) => {
            console.log(error);
            alert("Enter unique task name.")
        });
    };

    return (
        <form onSubmit={handleSubmit}>
            <h1 > Add new task</h1>
            <div>
                <label>Task Name:</label>
                <input
                    type="text"
                    value={taskName}
                    onChange={(e) => setTaskName(e.target.value)}
                />
            </div>
            <div>
                <label>Priority:</label>
                <input
                    type="number"
                    value={priority}
                    onChange={(e) => setPriority(parseInt(e.target.value))}
                    min="1"
                    max="5"
                    required
                />
            </div>
            <div>
                <label>Status:</label>
                <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                >
                    <option value="0">Not Started</option>
                    <option value="1">In Progress</option>
                    <option value="2">Completed</option>
                </select>
            </div>

            <button type="submit">Add Task</button>

        </form>
    );
}

export default AddTasks;
