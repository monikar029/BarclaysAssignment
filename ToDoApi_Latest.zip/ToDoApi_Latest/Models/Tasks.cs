﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace ToDoApi_Latest.Models
{
    public enum StatusType
    {
        [Description("Not Started")]
        NotStarted ,
        [Description("In Progress")]
        InProgress,
        [Description("Completed")]
        Completed

    }
    public static class EnumExtensions
    {
        //public static string GetDescription(this Enum value)
        //{
        //    var field = value.GetType().GetField(value.ToString());
        //    var attribute = field?.GetCustomAttribute<DescriptionAttribute>();
        //    return attribute?.Description ?? value.ToString();
        //}
    }
    public class Tasks
    {
        public Guid TaskId { get; set; }
        
        public string TaskName { get; set; }
        [Range(1, 5)]
        public int Priority { get; set; }

        [Range (0, 2)]
        public StatusType Status { get; set; }

        public Tasks(string name, int priority, StatusType status)
        {
            this.TaskName = name;
            this.Priority = priority;
            this.Status = status;
        }

        public Tasks(Guid id,string name, int priority, StatusType status)
        {
            this.TaskId = id;
            this.TaskName = name;
            this.Priority = priority;
            this.Status = status;
        }
    }
}
