﻿using System.ComponentModel;
using System.Reflection;
using ToDoApi_Latest.Models;

namespace ToDoApi_Latest.DataAccessLayer
{
    
    public class TaskDAL
    {
        public static readonly List<Tasks> _tasks = new List<Tasks>();

        public List<Tasks> GetAll()
        {
            return _tasks;
        }

        public Tasks AddTask(Tasks data)
        {
            data.TaskId = Guid.NewGuid();
            _tasks.Add(data);
            return data;
        }
        public Tasks UpdateTask( Guid id, string name, int priority, StatusType status)
        {
            var selectedTask = _tasks.FirstOrDefault(x => x.TaskId == id);
            if (selectedTask != null)
            {
                selectedTask.TaskName = name;
                selectedTask.Status = status;
                //if db save required for string : data.Status.GetDescription()
                selectedTask.Priority = priority;
            }
            return selectedTask;
        }
        public Tasks RemoveTask(Guid id)
        {
            var data = _tasks.FirstOrDefault(x => x.TaskId == id);
            _tasks.Remove(data);
            
            return data;
        }

        
    }
}
