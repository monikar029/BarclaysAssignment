﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using ToDoApi_Latest.DataAccessLayer;
using ToDoApi_Latest.Models;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BarclaysAssignment_ToDoApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TasksController : ControllerBase
    {
        //public static readonly List<Tasks> _tasks = new List<Tasks>();

        private readonly TaskDAL _taskModel;
        TaskDAL model = new TaskDAL();
        public TasksController()
        {
            _taskModel = new TaskDAL();
        }

        [HttpGet]
        public List<Tasks> GetAllTasks()
        {
            return model.GetAll();
        }

        [HttpPost]
        public IActionResult Add(string taskName, int priority, StatusType status)
        {
            var allData = model.GetAll();
            Tasks data = new(taskName, priority,status);

            if (!allData.Exists(x => x.TaskName == data.TaskName))
            {
                _taskModel.AddTask(data);
                return Ok(data);
            }
            else
            {
                return BadRequest("Task name already exists.");
            }
        }

        [HttpPut]
        public IActionResult Update(Guid id, string name, int priority, StatusType status)
        {
            var allData = model.GetAll();
            
            if (allData.Exists(x => x.TaskId == id))
            {
                _taskModel.UpdateTask(id, name, priority, status);
                var taskSelected = allData.FirstOrDefault(x => x.TaskId == id);
                return Ok(taskSelected);
            }
            else
            {
                return NotFound();
            }
            
        }


        [HttpDelete]
        public IActionResult Delete(Guid id)
        {
            var allData = model.GetAll();
            var tsk = allData.FirstOrDefault(x => x.TaskId == id);
            if (tsk != null && tsk.Status == StatusType.Completed)
            {
                var result = _taskModel.RemoveTask(id);
                return NoContent();
            }
            else
            {
                return BadRequest("Either task not found or is not in complete status");
            }
        }

    }
}
